/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,jsx,ts,tsx}"],
  theme: {
    extend: {
      colors: {
        bg: "#efe8dc",
        "bg-deep": "#1b365d",
        surface: "#f7f2ea",
        "surface-2": "#fffdf8",
        ink: "#1a1f2b",
        muted: "#5c6570",
        subtle: "#8a8074",
        line: "#d8cfc2",
        ember: "#b42318",
        "ember-fg": "#fff7f4",
        navy: "#1b365d",
        "navy-2": "#152a49",
        cream: "#f3ede4",
        "shift-a": "#9b2c2c",
        "shift-a-bg": "#f6e4e2",
        "shift-b": "#1f4e79",
        "shift-b-bg": "#e2ebf4",
        "shift-c": "#215c45",
        "shift-c-bg": "#e2efe8",
      },
      fontFamily: {
        display: ['"Barlow Condensed"', '"Arial Narrow"', "sans-serif"],
        sans: ['"IBM Plex Sans"', '"Segoe UI"', "system-ui", "sans-serif"],
      },
    },
  },
  plugins: [],
};
