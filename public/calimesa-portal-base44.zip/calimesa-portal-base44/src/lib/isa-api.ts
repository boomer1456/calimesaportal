import type { IsaEntry, IsaFirefighter, IsaMeta } from "@/lib/isa";

function payload<T>(input: T | { data: T }): T {
  if (input && typeof input === "object" && "data" in (input as object)) {
    return (input as { data: T }).data;
  }
  return input as T;
}

const KEY = "cfd-isa-house-v1";

type House = {
  roster: IsaFirefighter[];
  entries: IsaEntry[];
  meta: IsaMeta;
};

function empty(): House {
  return {
    roster: [],
    entries: [],
    meta: { college: "", agency: "Calimesa Fire", course: "", syn: "", instructor: "", term: "", reimbursementStatus: "" },
  };
}

function read(): House {
  try {
    const raw = localStorage.getItem(KEY);
    if (raw) return JSON.parse(raw) as House;
  } catch {
    /* ignore */
  }
  return empty();
}

function write(house: House) {
  localStorage.setItem(KEY, JSON.stringify(house));
  return house;
}

export async function listIsaHouse() {
  return read();
}

export async function addIsaHouseEntries(input: { data: { eventId?: string; iorPresent: boolean; drafts: IsaEntry[] } }) {
  const data = payload(input);
  const house = read();
  const batchId = `b-${Date.now()}`;
  const rows = (data.drafts ?? []).map((d, i) => ({
    ...d,
    id: d.id || `e-${Date.now()}-${i}`,
    batchId,
    eventId: data.eventId,
    iorPresent: data.iorPresent,
  }));
  house.entries = [...rows, ...house.entries];
  return { ok: true as const, house: write(house) };
}

export async function importIsaLocal(input: { data: { entries: IsaEntry[]; roster: IsaFirefighter[] } }) {
  const data = payload(input);
  const house = read();
  house.entries = data.entries ?? house.entries;
  house.roster = data.roster ?? house.roster;
  return write(house);
}

export async function verifyIsaAdmin(input: { data: { username: string; password: string } }) {
  const { username, password } = payload(input);
  if (!username || !password) return { ok: false as const, error: "Need a username and password." };
  return { ok: true as const };
}

export async function saveIsaFirefighter(input: { data: { firefighter: IsaFirefighter } & { username?: string } }) {
  const data = payload(input) as { firefighter: IsaFirefighter };
  const house = read();
  const ff = data.firefighter;
  const idx = house.roster.findIndex((r) => r.id === ff.id);
  if (idx >= 0) house.roster[idx] = ff;
  else house.roster.push(ff);
  return { ok: true as const, house: write(house) };
}

export async function removeIsaFirefighter(input: { data: { id: string } }) {
  const { id } = payload(input);
  const house = read();
  house.roster = house.roster.filter((r) => r.id !== id);
  return { ok: true as const, house: write(house) };
}

export async function removeIsaHouseEntry(input: { data: { id: string } }) {
  const { id } = payload(input);
  const house = read();
  house.entries = house.entries.filter((e) => e.id !== id);
  return { ok: true as const, house: write(house) };
}

export async function removeIsaHouseBatch(input: { data: { batchId: string } }) {
  const { batchId } = payload(input);
  const house = read();
  house.entries = house.entries.filter((e) => e.batchId !== batchId);
  return { ok: true as const, house: write(house) };
}

export async function saveIsaMeta(input: { data: { meta: IsaMeta } }) {
  const data = payload(input) as { meta: IsaMeta };
  const house = read();
  house.meta = { ...house.meta, ...data.meta };
  return { ok: true as const, house: write(house) };
}
