import { fillCityForm } from "@/lib/fill-city-form";
import { parseReceiptText } from "@/lib/parse-receipt";

function payload<T>(input: T | { data: T }): T {
  if (input && typeof input === "object" && "data" in (input as object)) {
    return (input as { data: T }).data;
  }
  return input as T;
}

const KEY = "cfd-pcard-archive-v1";

export async function parseReceipt(input: { data: { image: string } }) {
  const { image } = payload(input);
  try {
    const { ocrReceiptImage } = await import("@/lib/client-ocr");
    return await ocrReceiptImage(image);
  } catch {
    return parseReceiptText("");
  }
}

export async function fillProcurement(input: { data: Record<string, string | undefined> }) {
  const data = payload(input);
  const filled = await fillCityForm(
    {
      date: data.date ?? "",
      who: data.who ?? "",
      card: data.card ?? "",
      vendor: data.vendor ?? "",
      description: data.description ?? "",
      description2: data.description2 ?? "",
      coding: data.coding ?? "",
      amount: data.amount ?? "",
      supervisor: data.supervisor ?? "",
    },
    data.image,
  );
  const bytes = filled.bytes ?? new Uint8Array();
  let pdf = "";
  const chunk = 0x8000;
  for (let i = 0; i < bytes.length; i += chunk) {
    pdf += String.fromCharCode(...bytes.subarray(i, i + chunk));
  }
  return { pdf: btoa(pdf), name: filled.name };
}

function readList(): Array<Record<string, unknown>> {
  try {
    return JSON.parse(localStorage.getItem(KEY) || "[]");
  } catch {
    return [];
  }
}

function writeList(rows: Array<Record<string, unknown>>) {
  localStorage.setItem(KEY, JSON.stringify(rows));
  return rows;
}

export async function listPcards() {
  return readList().map(({ image, ...rest }) => rest);
}

export async function getPcard(input: { data: { id: string } }) {
  const { id } = payload(input);
  return readList().find((r) => r.id === id) ?? null;
}

export async function savePcard(input: { data: Record<string, unknown> }) {
  const data = payload(input);
  const rows = readList();
  const id = String(data.id || `pc-${Date.now()}`);
  const next = { ...data, id, updatedAt: new Date().toISOString() };
  const idx = rows.findIndex((r) => r.id === id);
  if (idx >= 0) rows[idx] = { ...rows[idx], ...next };
  else rows.unshift(next);
  writeList(rows);
  return next;
}

export async function deletePcard(input: { data: { id: string } }) {
  const { id } = payload(input);
  writeList(readList().filter((r) => r.id !== id));
  return { ok: true };
}
