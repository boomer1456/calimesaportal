function payload<T>(input: T | { data: T } | undefined): T {
  if (input && typeof input === "object" && "data" in (input as object)) {
    return (input as { data: T }).data;
  }
  return input as T;
}

const KEY = "cfd-par-house-v1";

type House = { qty: Record<string, number>; min: Record<string, number> };

function read(): House {
  try {
    const raw = localStorage.getItem(KEY);
    if (raw) return JSON.parse(raw) as House;
  } catch {
    /* ignore */
  }
  return { qty: {}, min: {} };
}

function write(house: House) {
  localStorage.setItem(KEY, JSON.stringify(house));
  return house;
}

export async function listParHouse() {
  return read();
}

export async function seedParHouse(input: { data: House } | House) {
  const data = payload(input);
  const cur = read();
  if (Object.keys(cur.qty).length || Object.keys(cur.min).length) return cur;
  return write({ qty: { ...data.qty }, min: { ...data.min } });
}

export async function bumpParQty(input: { data: { id: string; delta: number } }) {
  const { id, delta } = payload(input);
  const house = read();
  house.qty[id] = Math.max(0, (house.qty[id] ?? 0) + delta);
  return write(house);
}

export async function bumpParMin(input: { data: { id: string; delta: number; username?: string; password?: string } }) {
  const { id, delta } = payload(input);
  const house = read();
  house.min[id] = Math.max(0, (house.min[id] ?? 0) + delta);
  return { ok: true as const, house: write(house) };
}

export async function resetParQty() {
  const house = read();
  const next = { ...house, qty: {} };
  return { ok: true as const, house: write(next) };
}

export async function resetParMins() {
  const house = read();
  const next = { ...house, min: {} };
  return { ok: true as const, house: write(next) };
}

export async function resetFacilityQty() {
  return resetParQty();
}

export async function resetFacilityMins() {
  return resetParMins();
}
