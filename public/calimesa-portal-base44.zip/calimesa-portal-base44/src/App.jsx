import { BrowserRouter, Navigate, Route, Routes } from "react-router-dom";
import Home from "@/pages/Home";
import Binder from "@/pages/Binder";
import Calendar from "@/pages/Calendar";
import StationPar from "@/pages/StationPar";
import Radio from "@/pages/Radio";
import Pcard from "@/pages/Pcard";
import StrikeTeam from "@/pages/StrikeTeam";

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/Home" element={<Home />} />
        <Route path="/Binder" element={<Binder />} />
        <Route path="/Calendar" element={<Calendar />} />
        <Route path="/StationPar" element={<StationPar />} />
        <Route path="/Radio" element={<Radio />} />
        <Route path="/Pcard" element={<Pcard />} />
        <Route path="/StrikeTeam" element={<StrikeTeam />} />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </BrowserRouter>
  );
}
