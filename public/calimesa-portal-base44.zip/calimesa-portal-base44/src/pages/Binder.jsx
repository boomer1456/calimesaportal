import { useEffect } from "react";
import { AppShell } from "@/components/app-shell";
import { useTrainingStore } from "@/lib/store";

export default function Binder() {
  useEffect(() => {
    useTrainingStore.getState().setPolicyPane("policies");
    useTrainingStore.getState().setTab("policy");
  }, []);
  return <AppShell />;
}
