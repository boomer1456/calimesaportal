import { useEffect } from "react";
import { AppShell } from "@/components/app-shell";
import { useTrainingStore } from "@/lib/store";

export default function StrikeTeam() {
  useEffect(() => {
    useTrainingStore.getState().setTab("strike");
  }, []);
  return <AppShell />;
}
