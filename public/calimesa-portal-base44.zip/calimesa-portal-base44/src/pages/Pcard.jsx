import { useEffect } from "react";
import { AppShell } from "@/components/app-shell";
import { useTrainingStore } from "@/lib/store";

export default function Pcard() {
  useEffect(() => {
    useTrainingStore.getState().openPcard();
  }, []);
  return <AppShell />;
}
