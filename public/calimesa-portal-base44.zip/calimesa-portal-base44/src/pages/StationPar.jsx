import { useEffect } from "react";
import { AppShell } from "@/components/app-shell";
import { useTrainingStore } from "@/lib/store";

export default function StationPar() {
  useEffect(() => {
    useTrainingStore.getState().setTab("ems");
  }, []);
  return <AppShell />;
}
