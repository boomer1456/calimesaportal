import { useEffect } from "react";
import { AppShell } from "@/components/app-shell";
import { useTrainingStore } from "@/lib/store";

export default function Calendar() {
  useEffect(() => {
    useTrainingStore.getState().setTab("calendar");
  }, []);
  return <AppShell />;
}
