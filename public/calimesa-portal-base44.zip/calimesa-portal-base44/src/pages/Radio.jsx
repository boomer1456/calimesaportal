import { useEffect } from "react";
import { AppShell } from "@/components/app-shell";
import { useTrainingStore } from "@/lib/store";

export default function Radio() {
  useEffect(() => {
    useTrainingStore.getState().setPolicyPane("radio");
    useTrainingStore.getState().setTab("policy");
  }, []);
  return <AppShell />;
}
