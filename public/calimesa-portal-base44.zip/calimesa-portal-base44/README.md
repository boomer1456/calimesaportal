# Calimesa Portal — Base44 import

Station app for Calimesa Fire: binder, time card, P-card, PAR, radio, strike team, calendar.

This zip is laid out the way Base44 expects a React/Vite app.

```
src/pages          Home.jsx, Binder.jsx, Calendar.jsx, …
src/components     House UI
src/api            base44Client.js
src/lib            App logic
src/utils          Helpers
entities/          JSON schemas (PAR, ISA, P-card, time card, users)
functions/         Backend stubs
base44/            CLI config + entity copies
```

## Import into Base44

**GitHub (best)**
1. Unzip this folder.
2. Push it to a new GitHub repo (web app at the repo root).
3. In Base44: **Import from GitHub** and pick that repo.
4. After it builds, open Dashboard → GitHub if you want 2-way sync.

**Code tab**
1. Create a blank Base44 app.
2. Unzip locally.
3. Copy `src/`, `entities/`, `functions/`, `public/`, `package.json`, `vite.config.js`, `index.html`, `tailwind.config.js` into the Code tab.

**CLI**
```
npm install
npm install -g base44@latest
base44 login
base44 create
base44 link
base44 dev
```

Then in `src/api/base44Client.js` your app id is injected as `VITE_BASE44_APP_ID`.

## After import

Ask Base44 chat to:
- Turn on login and map the `User` entity (name, username, email, phone, role).
- Save PAR / ISA / P-card / time cards to entities instead of the phone’s local storage.
- Keep `public/docs` — those are the house PDFs.

House data (PAR counts, hours, P-card archive, time cards) currently stores on the device until you wire entities.

Node 20. `npm run dev` / `npm run build` for a local check.
